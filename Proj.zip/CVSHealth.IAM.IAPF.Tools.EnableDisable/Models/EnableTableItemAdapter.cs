﻿using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFRequest.Interfaces;
using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFTasks;

namespace CVSHealth.IAM.IAPF.Tools.EnableDisable.Models
{
    /// <summary>
    /// Adapter class to convert EnableTableItem to IRequestBuildItem.
    /// </summary>
    public class EnableTableItemAdapter : IRequestBuildItem
    {
        private readonly EnableTableItem _item;

        /// <summary>
        /// Initializes a new instance of the EnableTableItemAdapter class.
        /// </summary>
        /// <param name="item">The EnableTableItem to adapt.</param>
        public EnableTableItemAdapter(EnableTableItem item)
        {
            _item = item;
        }

        /// <summary>
        /// Gets the status of the item.
        /// </summary>
        public string Status => _item.Status;

        /// <summary>
        /// Gets the comment associated with the item.
        /// </summary>
        public string Comment => _item.Comment;

        /// <summary>
        /// Gets the action to be performed on the item.
        /// </summary>
        public string Action => _item.Action;

        /// <summary>
        /// Gets the scope of the item.
        /// </summary>
        public string Scope => _item.Scope;

        /// <summary>
        /// Gets the domain of the item.
        /// </summary>
        public string Domain => _item.Domain;

        /// <summary>
        /// Gets the SAM account of the item.
        /// </summary>
        public string SamAccount => _item.SamAccount;

        /// <summary>
        /// Gets the disable comment for the item.
        /// </summary>
        public string DisableComment => _item.DisableComment;

        /// <summary>
        /// Gets the user details associated with the item.
        /// </summary>
        public ADUserDetails UserDetails => _item.UserDetails!;
    }
}
