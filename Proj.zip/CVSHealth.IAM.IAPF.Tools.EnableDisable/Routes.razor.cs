﻿using Microsoft.AspNetCore.Components;

namespace CVSHealth.IAM.IAPF.Tools.EnableDisable
{
    /// <summary>
    /// Represents the routes for the AD Lookup tool.
    /// </summary>
    public partial class Routes
    {
        #region Injected Services

        #endregion

        // Add your route constants or methods here
    }
}
