﻿using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFRequest.Interfaces;
using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFRequest;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.Services.Interfaces
{
    /// <summary>
    /// Defines the interface for the request builder service.
    /// </summary>
    public interface IRequestBuilderService
    {
        /// <summary>
        /// Builds a dispose request model from a list of request build items.
        /// </summary>
        /// <param name="items">The list of request build items.</param>
        /// <returns>A RequestModel containing the dispose payload.</returns>
        RequestModel<RequestDisposePayloadModel> BuildDisposeRequest(List<IRequestBuildItem> items);

        /// <summary>
        /// Builds a reinstate request model from a list of request build items.
        /// </summary>
        /// <param name="items">The list of request build items.</param>
        /// <returns>A RequestModel containing the reinstate payload.</returns>
        RequestModel<RequestReinstatePayloadModel> BuildReinstateRequest(List<IRequestBuildItem> items);
    }
}
