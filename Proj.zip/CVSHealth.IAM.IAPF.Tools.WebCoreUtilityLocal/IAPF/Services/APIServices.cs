﻿using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.Application.Common.Configuration.Interfaces;
using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.Infrastructure.Services.Interfaces;
using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.NLog.LogService.Interface;
using Microsoft.Identity.Client;
using System.Text;
using System.Text.Json;
using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFTasks;
using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFRequest;

namespace CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.Services
{
    /// <summary>
    /// Provides services for making API requests related to enable/disable operations.
    /// </summary>
    public class APIServices
    {
        #region Fields

        private readonly IAppConfiguration _appConfiguration;
        private readonly HttpClient _httpClient;
        private IAzureAdOptions? _azureAdOptions;
        private ILogHelper? _logger;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="APIServices"/> class.
        /// </summary>
        /// <param name="appConfiguration">The application configuration.</param>
        public APIServices(IAppConfiguration appConfiguration, HttpClient httpClient, IAzureAdOptions azureAdOptions, ILogHelper logger)
        {
            _appConfiguration = appConfiguration ?? throw new ArgumentNullException(nameof(appConfiguration));
            _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            _azureAdOptions = azureAdOptions ?? throw new ArgumentNullException(nameof(azureAdOptions));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Posts a request message to the IAPF API.
        /// </summary>
        /// <param name="token">The authentication token.</param>
        /// <param name="requestBodyJson">The request body in JSON format.</param>
        /// <returns>An <see cref="IAPFResponse"/> object.</returns>
        public async Task<IAPFResponse> PostRequestMessage(string token, string requestBodyJson)
        {
            if (string.IsNullOrEmpty(token))
                throw new ArgumentException("Token cannot be null or empty.", nameof(token));

            if (string.IsNullOrEmpty(requestBodyJson))
                throw new ArgumentException("Request body JSON cannot be null or empty.", nameof(requestBodyJson));

            string iapfRequestURL = _appConfiguration.DynamicValues["RequestAPIURL"];

            using var request = new HttpRequestMessage(HttpMethod.Post, iapfRequestURL);
            request.Content = new StringContent(requestBodyJson, Encoding.UTF8, "application/json");
            request.Headers.Add("Authorization", $"Bearer {token}");

            using var response = await _httpClient.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            var iapfResponse = new IAPFResponse
            {
                RequestStatusCode = (int)response.StatusCode,
                RequestStatusDesc = response.ReasonPhrase
            };

            if (!string.IsNullOrEmpty(content))
            {
                try
                {
                    var deserializationOptions = new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    };

                    var deserializedResponse = JsonSerializer.Deserialize<IAPFResponse>(content, deserializationOptions);
                    if (deserializedResponse != null)
                    {
                        iapfResponse = deserializedResponse;
                        iapfResponse.RequestStatusCode = (int)response.StatusCode;
                        iapfResponse.RequestStatusDesc = response.ReasonPhrase;
                    }
                    else
                    {
                        iapfResponse.StatusComments = "Response was successfully deserialized, but resulted in a null object.";
                    }
                }
                catch (JsonException ex)
                {
                    iapfResponse.StatusComments = $"Error deserializing response: {ex.Message}";
                    iapfResponse.ErrorDetails = content;
                }
            }
            else
            {
                iapfResponse.StatusComments = "Response content was empty";
            }

            if (!response.IsSuccessStatusCode)
            {
                iapfResponse.StatusComments = $"Non-success status code received: {response.StatusCode}";
                _logger?.LogWarn($"Non-success status code: {response.StatusCode}. Content: {content}");
            }

            return iapfResponse;
        }

        /// <summary>
        /// Posts AD user details to the IAPF API.
        /// </summary>
        /// <param name="token">The authentication token.</param>
        /// <param name="requestBodyJson">The request body in JSON format.</param>
        /// <returns>An <see cref="ADUserDetails"/> object with the response.</returns>
        public async Task<ADUserDetails> PostADUserAccountTaskAPIDetails(string token, string requestBodyJson)
        {
            if (string.IsNullOrEmpty(token))
                throw new ArgumentException("Token cannot be null or empty.", nameof(token));

            if (string.IsNullOrEmpty(requestBodyJson))
                throw new ArgumentException("Request body JSON cannot be null or empty.", nameof(requestBodyJson));

            string iapfTaskURL = _appConfiguration.DynamicValues["TaskAPIURL"] + "ADUserAccount/UserAccount/Details";

            using var request = new HttpRequestMessage(HttpMethod.Post, iapfTaskURL);
            request.Content = new StringContent(requestBodyJson, Encoding.UTF8, "application/json");
            request.Headers.Add("Authorization", $"Bearer {token}");

            using var response = await _httpClient.SendAsync(request);
            var content = await response.Content.ReadAsStringAsync();

            var deserializationOptions = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            ADUserDetails? adUserDetails = null;

            if (response.IsSuccessStatusCode && !string.IsNullOrEmpty(content))
            {
                try
                {
                    adUserDetails = JsonSerializer.Deserialize<ADUserDetails>(content, deserializationOptions);
                    if (adUserDetails != null)
                    {
                        adUserDetails.SuccessCode = true;
                    }
                    else
                    {
                        _logger?.LogWarn("Response was successfully deserialized, but resulted in a null object.");
                    }
                }
                catch (JsonException ex)
                {
                    _logger?.LogError($"Error deserializing response: {ex.Message}", ex);
                }
            }

            if (adUserDetails == null)
            {
                adUserDetails = new ADUserDetails
                {
                    SuccessCode = false,
                    ErrorDesc = $"Failed to deserialize response. Status code: {response.StatusCode}"
                };
                _logger?.LogWarn($"Failed to deserialize response. Status code: {response.StatusCode}. Content: {content}");
            }

            return adUserDetails;
        }

        /// <summary>
        /// Gets an access token for authentication.
        /// </summary>
        /// <param name="clientId">The client ID.</param>
        /// <param name="secretValue">The client secret.</param>
        /// <param name="tenantId">The tenant ID.</param>
        /// <returns>An access token string.</returns>
        public async Task<AuthenticationResult> GetAccessToken(string clientId, string secretValue, string tenantId, string apiName)
        {
            if (string.IsNullOrEmpty(clientId))
                throw new ArgumentException("Client ID cannot be null or empty.", nameof(clientId));

            if (string.IsNullOrEmpty(secretValue))
                throw new ArgumentException("Secret value cannot be null or empty.", nameof(secretValue));

            if (string.IsNullOrEmpty(tenantId))
                throw new ArgumentException("Tenant ID cannot be null or empty.", nameof(tenantId));

            var app = ConfidentialClientApplicationBuilder
                .Create(clientId)
                .WithClientSecret(secretValue)  // Once AKeyLess is working, can set to ServicePrincipalAKeylessKey
                .WithAuthority(new Uri($"https://login.microsoftonline.com/{tenantId}"))
                .Build();

            // Extract scopes from ApiPermissions
            string[] scopes = _azureAdOptions!.ApiPermissions
                .Where(ap => ap.ApiName!.Equals(apiName, StringComparison.OrdinalIgnoreCase))
                .SelectMany(apiPermission => apiPermission.Scopes!)
                .ToArray();

            return await app.AcquireTokenForClient(scopes)
                .ExecuteAsync();
        }

        #endregion
    }
}