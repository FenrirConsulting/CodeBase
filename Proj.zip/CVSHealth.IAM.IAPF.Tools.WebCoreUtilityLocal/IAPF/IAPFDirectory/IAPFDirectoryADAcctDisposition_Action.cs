﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFDirectory
{
    // <summary>
    /// Represents an AD account disposition action in the IAPF directory.
    /// </summary>
    public class IAPFDirectoryADAcctDisposition_Action
    {
        #region Public Properties

        /// <summary>
        /// Gets or sets the unique batch identifier.
        /// </summary>
        [Key]
        [MaxLength(100)]
        public string? BatchID { get; set; }

        /// <summary>
        /// Gets or sets the creation date of the action.
        /// </summary>
        [MaxLength(30)]
        public string? WhenCreated { get; set; }

        /// <summary>
        /// Gets or sets the result of the action.
        /// </summary>
        [MaxLength(20)]
        public string? ActionResult { get; set; }

        /// <summary>
        /// Gets or sets the source domain.
        /// </summary>
        [MaxLength(200)]
        public string? SourceDomain { get; set; }

        /// <summary>
        /// Gets or sets the disabled status.
        /// </summary>
        public bool Disabled { get; set; }

        /// <summary>
        /// Gets or sets the source SAM account name.
        /// </summary>
        [MaxLength(200)]
        public string? SourceSamAccountName { get; set; }

        /// <summary>
        /// Gets or sets the source original Organizational Unit.
        /// </summary>
        [MaxLength(200)]
        public string? SourceOriginalOU { get; set; }

        /// <summary>
        /// Gets or sets the Extension Attribute 8 value.
        /// </summary>
        [MaxLength(200)]
        public string? ExtensionAttribute8 { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        [MaxLength(1000)]
        public string? Description { get; set; }

        /// <summary>
        /// Gets or sets the source manager.
        /// </summary>
        [MaxLength(200)]
        public string? SourceManager { get; set; }

        /// <summary>
        /// Gets or sets the source member of groups.
        /// </summary>
        [MaxLength(200)]
        public string? SourceMemberOf { get; set; }

        /// <summary>
        /// Gets or sets the employee number.
        /// </summary>
        [MaxLength(50)]
        public string? EmployeeNumber { get; set; }

        /// <summary>
        /// Gets or sets the msDBUseDefaults value.
        /// </summary>
        [MaxLength(200)]
        public string? mDBUseDefaults { get; set; }

        /// <summary>
        /// Gets or sets the msExchHideFromAddressList value.
        /// </summary>
        [MaxLength(1000)]
        public string? msExchHideFromAddressLists { get; set; }

        #endregion
    }
}
