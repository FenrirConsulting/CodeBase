﻿using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.DataProtection.EntityFrameworkCore;
using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.Domain.Entities.Configuration;
using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFDirectory;

namespace CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.Data
{
    public class IAPFDirectoryDbContext : DbContext
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the AppDbContext class.
        /// </summary>
        /// <param name="options">The options to be used by the DbContext.</param>
        public IAPFDirectoryDbContext(DbContextOptions<IAPFDirectoryDbContext> options) : base(options) { }

        #endregion

        #region DbSet Properties

        /// <summary>
        /// Gets or sets the IAPFDirectoryADAcctDispositionActions DbSet.
        /// </summary>
        public DbSet<IAPFDirectoryADAcctDisposition_Action> ADAcctDisposition_Action { get; set; } = null!;

        #endregion

        #region Public Methods

        /// <summary>
        /// Creates a new instance of AppDbContext.
        /// </summary>
        /// <param name="options">The options to be used by the DbContext.</param>
        /// <returns>A new instance of AppDbContext.</returns>
        public static IAPFDirectoryDbContext Create(DbContextOptions<IAPFDirectoryDbContext> options)
        {
            return new IAPFDirectoryDbContext(options);
        }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Configures the model that was discovered by convention from the entity types exposed in DbSet properties on your derived context.
        /// </summary>
        /// <param name="modelBuilder">The builder being used to construct the model for this context.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Add any additional model configurations here
            // For example:
            // modelBuilder.Entity<UserSettings>().HasIndex(u => u.UserId).IsUnique();
        }

        #endregion
    }
}
