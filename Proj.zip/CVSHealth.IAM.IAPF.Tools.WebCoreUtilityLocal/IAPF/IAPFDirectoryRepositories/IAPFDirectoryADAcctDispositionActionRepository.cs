﻿using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.Data;
using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFDirectory;
using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFDirectoryRepositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFDirectoryRepositories
{
    /// <summary>
    /// Implements the IAPFDirectoryADAcctDispositionAction repository operations.
    /// </summary>
    public class IAPFDirectoryADAcctDispositionActionRepository : IIAPFDirectoryADAcctDispositionActionRepository
    {
        #region Private Fields

        private readonly IAPFDirectoryDbContext _context;

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the IAPFDirectoryADAcctDispositionActionRepository class.
        /// </summary>
        /// <param name="context">The database context.</param>
        public IAPFDirectoryADAcctDispositionActionRepository(IAPFDirectoryDbContext context)
        {
            _context = context;
        }

        #endregion

        #region Public Methods

        /// <inheritdoc/>
        public async Task<IEnumerable<IAPFDirectoryADAcctDisposition_Action>> GetByBatchIds(IEnumerable<string> batchIds)
        {
            return await _context.ADAcctDisposition_Action
                .Where(a => batchIds.Contains(a.BatchID))
                .ToListAsync();
        }

        /// <inheritdoc/>
        public async Task<IEnumerable<IAPFDirectoryADAcctDisposition_Action>> GetBySAMAccount(string samAccount)
        {
            return await _context.ADAcctDisposition_Action
                .Where(a => a.SourceSamAccountName == samAccount)
                .ToListAsync();
        }

        /// <inheritdoc/>
        public async Task<IEnumerable<IAPFDirectoryADAcctDisposition_Action>> GetByEmployeeNumber(string employeeNumber)
        {
            return await _context.ADAcctDisposition_Action
                .Where(a => a.EmployeeNumber == employeeNumber)
                .ToListAsync();
        }

        #endregion
    }
}
