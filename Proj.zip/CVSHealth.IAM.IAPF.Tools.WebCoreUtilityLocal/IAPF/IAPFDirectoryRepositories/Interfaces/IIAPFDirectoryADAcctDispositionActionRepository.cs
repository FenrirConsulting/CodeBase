﻿using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFDirectory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFDirectoryRepositories.Interfaces
{
    /// <summary>
    /// Defines the interface for IAPFDirectoryADAcctDispositionAction repository operations.
    /// </summary>
    public interface IIAPFDirectoryADAcctDispositionActionRepository
    {
        /// <summary>
        /// Gets the IAPFDirectoryADAcctDisposition_Action entries by batch IDs.
        /// </summary>
        /// <param name="batchIds">The batch IDs to search for.</param>
        /// <returns>A collection of IAPFDirectoryADAcctDisposition_Action entries.</returns>
        Task<IEnumerable<IAPFDirectoryADAcctDisposition_Action>> GetByBatchIds(IEnumerable<string> batchIds);

        /// <summary>
        /// Gets the IAPFDirectoryADAcctDisposition_Action entries by SAM account.
        /// </summary>
        /// <param name="samAccount">The SAM account to search for.</param>
        /// <returns>A collection of IAPFDirectoryADAcctDisposition_Action entries.</returns>
        Task<IEnumerable<IAPFDirectoryADAcctDisposition_Action>> GetBySAMAccount(string samAccount);

        /// <summary>
        /// Gets the IAPFDirectoryADAcctDisposition_Action entries by employee number.
        /// </summary>
        /// <param name="employeeNumber">The employee number to search for.</param>
        /// <returns>A collection of IAPFDirectoryADAcctDisposition_Action entries.</returns>
        Task<IEnumerable<IAPFDirectoryADAcctDisposition_Action>> GetByEmployeeNumber(string employeeNumber);
    }
}
