﻿using CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFTasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFRequest.Interfaces
{
    /// <summary>
    /// Defines the interface for items used in building requests.
    /// </summary>
    public interface IRequestBuildItem
    {
        /// <summary>
        /// Gets the status of the item.
        /// </summary>
        string Status { get; }

        /// <summary>
        /// Gets the comment associated with the item.
        /// </summary>
        string Comment { get; }

        /// <summary>
        /// Gets the action to be performed on the item.
        /// </summary>
        string Action { get; }

        /// <summary>
        /// Gets the scope of the item.
        /// </summary>
        string Scope { get; }

        /// <summary>
        /// Gets the domain of the item.
        /// </summary>
        string Domain { get; }

        /// <summary>
        /// Gets the SAM account of the item.
        /// </summary>
        string SamAccount { get; }

        /// <summary>
        /// Gets the disable comment for the item.
        /// </summary>
        string DisableComment { get; }

        /// <summary>
        /// Gets the user details associated with the item.
        /// </summary>
        ADUserDetails UserDetails { get; }
    }
}
