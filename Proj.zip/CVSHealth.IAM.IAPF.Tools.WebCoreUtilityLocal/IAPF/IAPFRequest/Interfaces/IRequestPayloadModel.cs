﻿namespace CVSHealth.IAM.IAPF.Tools.WebCoreUtility.IAPF.IAPFRequest.Interfaces
{
    public interface IRequestPayloadModel
    {
    }
}
