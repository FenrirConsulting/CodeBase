﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeimdallCloud.Shared.Services
{
    public class ReportRequirement : IAuthorizationRequirement
    {
        public string ?ReportName { get; }

        public ReportRequirement(string reportName)
        {
            ReportName = reportName;
        }
    }
}
