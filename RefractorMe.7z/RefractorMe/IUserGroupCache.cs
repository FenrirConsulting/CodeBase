﻿using System;

namespace HeimdallCloud.Shared.Services.IServices
{
    public interface IUserGroupCache
    {
        List<string> UserGroupNames { get; set; }
        string ?UserDisplayName { get; set; }
        string ?UserUid { get; set; }
        bool IsUserInGroup(string groupName);
        bool UserDisplayNameIs(string displayName);
    }
}
