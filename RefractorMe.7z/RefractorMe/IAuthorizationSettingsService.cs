﻿using HeimdallCloud.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeimdallCloud.Shared.Services.IServices
{
    public interface IAuthorizationSettingsService
    {
        public Task<AuthorizationSettings> LoadAuthorizationSettingsFromDatabase();
    }
}
