﻿using Microsoft.Identity.Web;
using Microsoft.PowerBI.Api;
using Microsoft.Rest;
using Microsoft.PowerBI.Api.Models;
using Microsoft.Extensions.Configuration;
using HeimdallCloud.Shared.Services.IServices;
using HeimdallCloud.Shared.Models;
using Microsoft.AspNetCore.Components;

namespace HeimdallCloud.Shared.Services
{
    public class PowerBiServiceAPI : IPowerBiServiceAPI
    {
        [Inject]
        private ITokenService? _TokenService { get; set; }

        private readonly string? _workspaceId;
        private string urlPowerBiServiceApiRoot { get; set; }
        public string? CurrentPowerBiToken { get; set; }
        public EmbeddedReportViewModel EmbeddedReportViewModel { get; set; } = new();

        // Constructor
        public PowerBiServiceAPI(IConfiguration configuration, ITokenService tokenService)
        {
            _workspaceId = configuration["PowerBiAPI:WorkspaceId"];
            urlPowerBiServiceApiRoot = configuration["PowerBiAPI:ServiceRootUrl"]!;
            _TokenService = tokenService;
        }

        // Create the Bi Client using Access Token
        public async Task<PowerBIClient> GetPowerBiClient()
        {
            var accessToken = await _TokenService!.AcquirePowerBiServicePrincipalTokenAsync();
            var tokenCredentials = new TokenCredentials(accessToken, "Bearer");
            CurrentPowerBiToken = accessToken;
            return new PowerBIClient(new Uri(urlPowerBiServiceApiRoot), tokenCredentials);
        }

        // Create the Embed Configuration using PowerBi Client and ReportId Parameter
        public async Task<EmbeddedReportViewModel> GetReportEmbedConfig(string reportId)
        {
            if (!Guid.TryParse(_workspaceId, out Guid workspaceGuid) || !Guid.TryParse(reportId, out Guid reportGuid))
            {
                // Handle the case where the provided ID's are not valid Guids
                throw new ArgumentException("Invalid workspaceId or reportId.");
            }

            PowerBIClient pbiClient = await GetPowerBiClient();
            var report = await pbiClient.Reports.GetReportAsync(workspaceGuid, reportGuid);

            var generateTokenRequestParameters = new GenerateTokenRequest(TokenAccessLevel.View, report.DatasetId);
            var tokenResponse = await pbiClient.Reports.GenerateTokenAsync(workspaceGuid, reportGuid, generateTokenRequestParameters);
            string embedToken = tokenResponse.Token.ToString();

            string srcBuilt = $"{report.EmbedUrl}&accessToken={Uri.EscapeDataString(embedToken)}";

            var embedReport = new EmbeddedReportViewModel
            {
                Id = report.Id.ToString(),
                EmbedUrl = report.EmbedUrl,
                Name = report.Name,
                EmbedToken = embedToken,
                IFrameSRC = srcBuilt
            };

            EmbeddedReportViewModel = embedReport;

            return embedReport;
        }
    }
}
