﻿using Microsoft.Graph;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeimdallCloud.Shared.Services.IServices
{
    public interface IGraphServiceAPI
    {
        List<string> UserGroups { get; }
        public Task<GraphServiceClient> CreateGraphClient();
        public Task<Microsoft.Graph.Models.User> GetUserInformation(string userId);
        public Task<Microsoft.Graph.Models.DirectoryObjectCollectionResponse> GetUserGroupMemberships(string userId);
    }
}
