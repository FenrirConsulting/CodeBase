﻿using HeimdallCloud.Shared.Models;
using HeimdallCloud.Shared.Services.IServices;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeimdallCloud.Shared.Services
{
    public class AuthorizationSettingsHostedService : IHostedService
    {
        private readonly IServiceProvider ?_serviceProvider;
        private readonly AuthorizationSettings _authorizationSettings;

        public AuthorizationSettingsHostedService(IServiceProvider serviceProvider, AuthorizationSettings authorizationSettings)
        {
            _serviceProvider = serviceProvider;
            _authorizationSettings = authorizationSettings;
        }

        public async Task StartAsync(CancellationToken cancellationToken)
        {
            using var scope = _serviceProvider!.CreateScope();
            var options = scope.ServiceProvider.GetRequiredService<IOptions<AuthorizationOptions>>().Value;
            var settingsService = scope.ServiceProvider.GetRequiredService<IAuthorizationSettingsService>();

            var loadedSettings = await settingsService.LoadAuthorizationSettingsFromDatabase();

            _authorizationSettings.Policies = loadedSettings!.Policies;
            _authorizationSettings.Roles = loadedSettings!.Roles;
            _authorizationSettings.ReportGroups = loadedSettings!.ReportGroups;

            

            // Policies based on Policy Settings
            if (loadedSettings.Policies != null)
            {
                foreach (var policy in loadedSettings.Policies)
                {
                    options.AddPolicy(policy.Key, p => p.Requirements.Add(new GroupRequirement(policy.Value)));
                }
                
            }

            // Policies based on Role Settings
            if (loadedSettings.Roles != null)
            {
                foreach (var role in loadedSettings.Roles)
                {
                    options.AddPolicy(role.Key, r => r.Requirements.Add(new GroupRequirement(role.Value)));
                }
            }

            
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }
}
