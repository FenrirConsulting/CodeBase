﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HeimdallCloud.Shared.Models;

namespace HeimdallCloud.Shared.Services.IServices
{
    public interface IPowerBiServiceAPI
    {
        Task<EmbeddedReportViewModel> GetReportEmbedConfig(string reportId);

        public EmbeddedReportViewModel EmbeddedReportViewModel {get;}
    }
}
