﻿using HeimdallCloud.Infrastructure.Shared.DataAccess.Data;
using HeimdallCloud.Shared.Models;
using HeimdallCloud.Shared.Services.IServices;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeimdallCloud.Shared.Services
{
    public class AuthorizationSettingsService : IAuthorizationSettingsService
    {
        private readonly ApplicationDbContext dbContext;

        public AuthorizationSettingsService(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public async Task<AuthorizationSettings> LoadAuthorizationSettingsFromDatabase()
        {
            // Load the authorization settings from the database and populate the AuthorizationSettings object
            var authorizationSettings = new AuthorizationSettings();

            var authorizationSettingsFromDb = await dbContext.IAMHAuthorizationSettings.ToListAsync();

            foreach (var setting in authorizationSettingsFromDb)
            {
                if (setting.Type == "Policies")
                {
                    if (authorizationSettings.Policies == null)
                    {
                        authorizationSettings.Policies = new Dictionary<string, string>();
                    }

                    authorizationSettings.Policies.Add(setting.Rule!, setting.Value!);
                }
                else if (setting.Type == "Roles")
                {
                    if (authorizationSettings.Roles == null)
                    {
                        authorizationSettings.Roles = new Dictionary<string, string>();
                    }

                    authorizationSettings.Roles.Add(setting.Rule!, setting.Value!);
                }

                if (authorizationSettings.ReportGroups == null)
                {
                    authorizationSettings.ReportGroups = new Dictionary<string, string>();
                    authorizationSettings.ReportGroups.Add(setting.Rule!, setting.ReportsAssignmentGroup!);
                }
                else
                {
                    authorizationSettings.ReportGroups.Add(setting.Rule!, setting.ReportsAssignmentGroup!);
                }
            }
            return authorizationSettings;
        }
    }
}
