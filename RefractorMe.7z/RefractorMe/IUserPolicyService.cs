﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace HeimdallCloud.Shared.Services.IServices
{
    public interface IUserPolicyService
    {
        Task<List<string>> GetAuthorizedPoliciesAsync(ClaimsPrincipal user);
    }
}
