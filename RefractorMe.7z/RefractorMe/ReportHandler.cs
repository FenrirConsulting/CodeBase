﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeimdallCloud.Shared.Services
{
    public class ReportHandler : AuthorizationHandler<ReportRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ReportRequirement requirement)
        {
           if (context.User.HasClaim(c=> c.Type == "ReportPermission" && c.Value == requirement.ReportName))
            {
                context.Succeed(requirement);
            }
           
           return Task.CompletedTask;
        }
    }
}
