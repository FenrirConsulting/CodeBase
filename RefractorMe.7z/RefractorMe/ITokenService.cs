﻿using HeimdallCloud.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace HeimdallCloud.Shared.Services.IServices
{
    public interface ITokenService
    {
        string? CurrentToken { get; }
        string? CurrentGraphToken { get; }
        string? CurrentPowerBiToken { get; }
        string? CurrentPowerBiServicePrincipalToken { get; }
        string? CurrentUID { get; }
        string? CurrentUserDisplayName { get; }
        public List<string>? UserGroupNames { get; }
        public List<string>? AuthorizedPolicies { get; }

        bool IsUserInGroup(string groupName);
        bool UserDisplayNameIs(string displayName);

        Task InitializeUserGroups(ClaimsPrincipal user);
        Task RetrieveAndStoreGroupIds(string userId);
        Task<bool> SetCurrentUserDisplayName();
        Task<string> AcquireTokenAsync(string[] scopes);
        Task<string> AcquireGraphTokenAsync(string UserId);
        Task<string> AcquirePowerBiTokenAsync();
        Task<string> AcquirePowerBiServicePrincipalTokenAsync();
        string AcquirePowerBiServicePrincipalToken();

    }
}
