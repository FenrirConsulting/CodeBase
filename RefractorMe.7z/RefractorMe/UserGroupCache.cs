﻿using HeimdallCloud.Shared.Services.IServices;

namespace HeimdallCloud.Shared.Services
{
    public class UserGroupCache : IUserGroupCache
    {
        public List<string> UserGroupNames { get; set; } = new List<string>();
        public string? UserUid { get; set; }
        public string? UserDisplayName { get; set; }

        public bool IsUserInGroup(string groupName)
        {
            return UserGroupNames?.Contains(groupName) ?? false;
        }

        public bool UserDisplayNameIs(string displayName)
        {
            if (UserDisplayName == displayName) return true;
            else return false;
        }
    }
}
